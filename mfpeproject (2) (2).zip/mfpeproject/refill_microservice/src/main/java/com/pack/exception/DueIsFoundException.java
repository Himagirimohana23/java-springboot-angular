package com.pack.exception;

public class DueIsFoundException extends Exception {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public DueIsFoundException(String msg) {
		super(msg);
	}

}
