package com.pack.exception;

public class MemberSubscriptionNotFoundException extends Exception {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public MemberSubscriptionNotFoundException(String msg) {
		super(msg);
	}
}
