package com.pack.exception;

public class DrugLocationNotFound extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public DrugLocationNotFound(String msg) {
		super(msg);
	}
}
