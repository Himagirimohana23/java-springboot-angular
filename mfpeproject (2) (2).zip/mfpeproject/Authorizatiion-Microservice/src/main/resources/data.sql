insert into users (id, password, user_name) values (1, '$2a$10$BhBZRNJZKsGHc4K6oC64w.EQWT7mb2DcgBXT0CkJMBxJDLHIfkCkK', 'admin');
insert into users (id, password, user_name) values (2, 'member1', 'member1');
insert into users (id, password, user_name) values (3, '$2a$10$YnXvrEntVWd89EpHhqubbO8EPfAQrjgnYevbuSaHJ81C0B/vANp9y', 'user2');
insert into users (id, password, user_name) values (4, 'm01', 'm01');
insert into users (id, password, user_name) values (5, 'm02', 'm02');
insert into users (id, password, user_name) values (6, 'm03', 'm03');

