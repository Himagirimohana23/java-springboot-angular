package com.pack.exception;

public class DrugDetailNotFoundException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public DrugDetailNotFoundException(String msg) {
		super(msg);
	}
}
