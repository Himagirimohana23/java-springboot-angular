insert into member_subscription ( SUBSCRIPTION_ID,DATE, DOCTOR_NAME, DRUG_NAME, MEMBER_ID, MEMBER_LOCATION, QUANTITY,REFILL_OCCURRENCE, STATUS,COURSE)
values (2, parsedatetime('01-03-2022', 'dd-MM-yyyy'), 'KP Yadav', 'Crocin', 'm01', 'Chennai', 10, 0, true, 'weekly');
insert into member_subscription ( SUBSCRIPTION_ID,DATE, DOCTOR_NAME, DRUG_NAME, MEMBER_ID, MEMBER_LOCATION, QUANTITY,REFILL_OCCURRENCE, STATUS,COURSE)
values (3, parsedatetime('01-02-2022', 'dd-MM-yyyy'), 'Vinod Singh', 'Paracetamol', 'm02', 'Chennai', 1000, 0, true,'monthly');
insert into member_subscription ( SUBSCRIPTION_ID,DATE, DOCTOR_NAME, DRUG_NAME, MEMBER_ID, MEMBER_LOCATION, QUANTITY,REFILL_OCCURRENCE, STATUS,COURSE)
values (4, parsedatetime('08-03-2022', 'dd-MM-yyyy'), 'Kanhaiya', 'Paracetamol', 'm02', 'Chennai', 9, 0, false, 'weekly');
insert into member_subscription ( SUBSCRIPTION_ID,DATE, DOCTOR_NAME, DRUG_NAME, MEMBER_ID, MEMBER_LOCATION, QUANTITY,REFILL_OCCURRENCE, STATUS,COURSE)
values (5, parsedatetime('01-02-2022', 'dd-MM-yyyy'), 'Upamanyu', 'Crocin', 'm03', 'Chennai', 4, 0, true, 'monthly');
insert into member_subscription ( SUBSCRIPTION_ID,DATE, DOCTOR_NAME, DRUG_NAME, MEMBER_ID, MEMBER_LOCATION, QUANTITY,REFILL_OCCURRENCE, STATUS,COURSE)
values (6, parsedatetime('01-02-2022', 'dd-MM-yyyy'), 'Upamanyu', 'Paracetamol', 'm03', 'Chennai', 4, 0, true, 'weekly');