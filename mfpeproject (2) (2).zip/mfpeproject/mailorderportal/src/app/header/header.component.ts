import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { MailserviceService } from '../mailservice.service';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {

  result:boolean=false;
  constructor(private service : MailserviceService, private router:Router) {
    
  }


  ngOnInit(): void {
    this.result = this.service.canActive();
  }
  
  
 
}
