import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';
import { MemberSubscription } from 'src/model/MemberSubscription';
import { RefillOrder } from 'src/model/RefillOrder';
import { RefillPojo } from 'src/model/RefillPojo';
import { MailserviceService } from '../mailservice.service';

@Component({
  selector: 'app-subscription-list',
  templateUrl: './subscription-list.component.html',
  styleUrls: ['./subscription-list.component.css']
})
export class SubscriptionListComponent implements OnInit {

  constructor(private service:MailserviceService, private router:Router) { 
   
 
  }
  sid:number = 0;
  refillOrderList:RefillOrder[] = [];
  subscriptionList: MemberSubscription[] = [];
  empty!: boolean;
  refillmessage :string ="";
  refillmsgred:string="";

checkform = new FormGroup({
  check: new FormControl(''),
});

  headElements = ['Subcription ID', 'Member Location', 'Drug Name','Quantity', 'LastDate', 'Refilling Frequency', 'View Status','Add Order','UnSubscribe'];

  refillOrder!:RefillOrder;

  ngOnInit(): void {

    this.service.isLogin().subscribe(data=>{

      if(!data){

        this.router.navigate(['/']);

      }

    });

    this.populateList();

    this.populateList2(this.sid);

  }



  populateList(){

    this.service.getSubscriptionList().subscribe(data=>{
      console.log(data);
      this.subscriptionList = data;
      
      if(data.length>0){
        this.empty = true;
      }
      else{
        this.empty = false;
      }


    });

  }

  

  viewStatus(id : number){

      this.router.navigateByUrl('/viewrefillstatus/'+id);

  }

  orderRefill(id:number){
    console.log(this.checkform.value.check);
    console.log(id);
    
    let refill =new RefillPojo(this.checkform.value.check,this.service.getUserName(),id);
    this.service.addRefillOrder(refill).subscribe();
    this.refillmessage = "your order of refilling is added  successfully. you can check your details in refill status"
    


  }

  unsubscribe(id:number){
    this.sid = id;
    let i=this.populateList2(id);
    console.log(i);
    if(i==0){
      console.log(id)
      this.service.unSubscribe(id).subscribe(data=>{
        console.log(data) 
        this.refillmessage="Successfully Unsubscribed. you can subscribe again"  
      },
      error=>{
        if(error.status==500){
          this.refillmsgred="You have not placed any refill order. Please add refill to unsubscribe"
        }
      }
      );
      
    }
    else{
      this.refillmsgred = "Unsubscription cannot be done. Payment dues are remaining for this subscription. Check in My Dues section"
    }
    
   
  }

  populateList2(id:number){
  
    this.service.getRefillOrderListWithDues().subscribe(data=>{
     
      
      this.refillOrderList = data;

    });
    let count1=0;
    for(let count=0;count<this.refillOrderList.length;count++){
      if(this.refillOrderList[count].subsId==id){
        count1+=1;
      }

    }
    console.log(count1)
    return count1;
  }

}
