import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { JwtRequest } from 'src/model/JwtRequest';
import { JwtResponse } from 'src/model/JwtResponse';
import { MailserviceService } from '../mailservice.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  //to display errors
  formError = ""
  outtoken:JwtResponse = new JwtResponse('');
  constructor(private service : MailserviceService,
    private router: Router) { }
    loginForm: FormGroup = new FormGroup({})
  
  ngOnInit(): void {
    this.loginForm = new FormGroup({
      userName: new FormControl('',[
       Validators.required,
       Validators.minLength(3)
      ]),
      password: new FormControl('',[
       Validators.required
      ])
    });
  }

  get userName() { return this.loginForm.get('userName') }
  get password() { return this.loginForm.get('password') }


  authorize(){
    this.formError=""
    let request = new JwtRequest(this.loginForm.value.userName, this.loginForm.value.password);
    console.log(request);
    this.service.userlogin(request).subscribe(data=>{
       this.outtoken = data;
       console.log(this.outtoken)
       let result = this.service.isLogin();
       result.subscribe(data =>{
        if(data){
          this.router.navigate(['dashboard'])
        }
        else{
          this.router.navigate([''])
        }
      },
      error=>{
        console.log("authorization"+error)
        this.formError="Something went wrong. please login again"
        this.loginForm.reset({})
        
      });

    },
    error=>{
      console.log("authentication"+error)
      this.formError = "Invalid Credentials"
      this.loginForm.reset({
      })
  
    });
  }



}
