export class RefillOrder{
    refillOrderId:number = 0;
    refillDate:Date = new Date();
    memberId:string = '';
    subsId:number = 0;
    paymentStatus:boolean = true;
}