export class DuesInformation{
    subsId:number =0;
    memId:string = '';
    daysLagging:string = '';
    drugName:string ='';
}