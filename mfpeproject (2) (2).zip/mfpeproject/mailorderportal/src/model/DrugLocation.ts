export class DrugLocation{
    
	id:number = 0;
	location : string = '';
	quantity : number = 0;
}