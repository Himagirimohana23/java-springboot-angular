export class Status{
	 isStatusYes:boolean = false;
	 statusDescription:string = "";
}